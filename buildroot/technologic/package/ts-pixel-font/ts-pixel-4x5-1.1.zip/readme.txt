﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “ts-kris”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/1834251

*NOTE: “TS pixel 4x5” was originally cloned (copied) from the FontStruction
“Unnamed 4x5” (https://fontstruct.com/fontstructions/show/1591583) by
“ImmaPooh”, which is licensed under a Open Font License license
(https://fontstruct.com/fontstructions/license/1591583).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2020 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.

The TTF was imported to Fontforge and consequently modified further there due
to limitations of Fontstruct. The Fontforge source file is included here as well.
